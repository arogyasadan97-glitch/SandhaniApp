using System.Diagnostics;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SandhaniApp.Data;
using SandhaniApp.Models;

namespace SandhaniApp.Controllers;

public class HomeController : Controller
{
    private readonly ApplicationDbContext _context;

    public HomeController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult Index() => View();

    public IActionResult Privacy() => View();

    public IActionResult About() => View();

    [HttpGet]
    public async Task<IActionResult> RequestBlood()
    {
        var model = new RequestBloodViewModel
        {
            RequiredDate = DateTime.Today
        };

        await LoadBloodGroupsAsync();
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> RequestBlood(RequestBloodViewModel model)
    {
        if (!ModelState.IsValid)
        {
            await LoadBloodGroupsAsync();
            return View(model);
        }

        var location = new Location
        {
            Division = model.Division?.Trim(),
            District = model.District?.Trim(),
            Upazila = model.Area?.Trim()
        };

        _context.Locations.Add(location);

        var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier);
        int? userId = int.TryParse(userIdValue, out var parsedUserId)
            ? parsedUserId
            : null;

        var bloodRequest = new BloodRequest
        {
            UserId = userId,
            BloodGroupId = model.BloodGroupId,
            Location = location,
            PatientName = model.PatientName.Trim(),
            ContactNumber = model.ContactNumber.Trim(),
            RequiredQuantity = model.RequiredQuantity,
            Hospital = model.Hospital.Trim(),
            RequiredDate = model.RequiredDate,
            EmergencyLevel = model.EmergencyLevel,
            Description = string.IsNullOrWhiteSpace(model.Description)
                ? null
                : model.Description.Trim(),
            Status = "Pending",
            CreatedAt = DateTime.UtcNow
        };

        _context.BloodRequests.Add(bloodRequest);
        await _context.SaveChangesAsync();

        TempData["Success"] =
            "Blood request submitted successfully. Sandhani Donor Club will process your request.";

        return RedirectToAction(nameof(RequestBlood));
    }

    private async Task LoadBloodGroupsAsync()
    {
        ViewBag.BloodGroups = await _context.BloodGroups
            .AsNoTracking()
            .OrderBy(b => b.BloodGroupName)
            .ToListAsync();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel
        {
            RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
        });
    }
}
