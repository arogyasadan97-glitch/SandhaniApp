using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SandhaniApp.Data;

namespace SandhaniApp.Controllers;

[Authorize(Roles = "Admin")]
public class AdminController : Controller
{
    private readonly ApplicationDbContext _context;

    public AdminController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> Dashboard()
    {
        ViewBag.UserCount = await _context.Users.CountAsync();
        ViewBag.DonorCount = await _context.Donors.CountAsync();
        ViewBag.BloodRequestCount = await _context.BloodRequests.CountAsync();

        return View();
    }
}
