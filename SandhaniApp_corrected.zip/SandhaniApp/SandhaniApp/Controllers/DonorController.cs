﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SandhaniApp.Data;
using SandhaniApp.Models;

namespace SandhaniApp.Controllers
{
    public class DonorController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DonorController(ApplicationDbContext context)
        {
            _context = context;
        }

        // FIND DONOR PAGE
        [HttpGet]
        public async Task<IActionResult> Search()
        {
            var model = new DonorSearchViewModel
            {
                IsAvailable = true,

                BloodGroups = await _context.BloodGroups
                    .OrderBy(b => b.BloodGroupName)
                    .ToListAsync()
            };

            return View(model);
        }

        // SEARCH DONORS
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Search(
            DonorSearchViewModel model)
        {
            // Load blood groups again
            model.BloodGroups = await _context.BloodGroups
                .OrderBy(b => b.BloodGroupName)
                .ToListAsync();

            // Start donor query
            var query =
                from donor in _context.Donors
                join user in _context.Users
                    on donor.UserId equals user.UserId
                join bloodGroup in _context.BloodGroups
                    on donor.BloodGroupId equals bloodGroup.BloodGroupId
                join location in _context.Locations
                    on donor.LocationId equals location.LocationId
                    into locationGroup
                from location in locationGroup.DefaultIfEmpty()
                select new
                {
                    Donor = donor,
                    User = user,
                    BloodGroup = bloodGroup,
                    Location = location
                };

            // Blood group filter
            if (model.BloodGroupId.HasValue &&
                model.BloodGroupId.Value > 0)
            {
                query = query.Where(x =>
                    x.Donor.BloodGroupId ==
                    model.BloodGroupId.Value);
            }

            // Available donor filter
            if (model.IsAvailable)
            {
                query = query.Where(x =>
                    x.Donor.IsAvailable);
            }

            // Division filter
            if (!string.IsNullOrWhiteSpace(model.Division))
            {
                query = query.Where(x =>
                    x.Location != null &&
                    x.Location.Division != null &&
                    x.Location.Division.Contains(model.Division));
            }

            // District filter
            if (!string.IsNullOrWhiteSpace(model.District))
            {
                query = query.Where(x =>
                    x.Location != null &&
                    x.Location.District != null &&
                    x.Location.District.Contains(model.District));
            }

            // Area / Upazila filter
            if (!string.IsNullOrWhiteSpace(model.Area))
            {
                query = query.Where(x =>
                    x.Location != null &&
                    (
                        (x.Location.Upazila != null &&
                         x.Location.Upazila.Contains(model.Area))
                        ||
                        (x.Location.Area != null &&
                         x.Location.Area.Contains(model.Area))
                    ));
            }

            // Create result list
            model.Results = await query
                .OrderBy(x => x.User.FullName)
                .Select(x => new DonorSearchResult
                {
                    DonorId = x.Donor.DonorId,
                    UserId = x.User.UserId,

                    FullName = x.User.FullName,
                    PhoneNumber = x.User.PhoneNumber,

                    BloodGroup = x.BloodGroup.BloodGroupName,

                    Division = x.Location != null
                        ? x.Location.Division
                        : null,

                    District = x.Location != null
                        ? x.Location.District
                        : null,

                    Area = x.Location != null
                        ? (
                            x.Location.Upazila ??
                            x.Location.Area
                          )
                        : null,

                    LastDonationDate =
                        x.Donor.LastDonationDate,

                    IsAvailable =
                        x.Donor.IsAvailable
                })
                .ToListAsync();

            return View(model);
        }
    }
}