using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SandhaniApp.Data;
using SandhaniApp.Models;

namespace SandhaniApp.Controllers;

[Authorize]
public class DashboardController : Controller
{
    private readonly ApplicationDbContext _context;

    public DashboardController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var userIdValue = User.FindFirstValue(ClaimTypes.NameIdentifier);

        if (!int.TryParse(userIdValue, out var userId))
            return RedirectToAction("Login", "Account");

        var user = await _context.Users
            .AsNoTracking()
            .SingleOrDefaultAsync(u => u.UserId == userId);

        if (user == null || !user.IsActive)
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Account");
        }

        var totalRequests = await _context.BloodRequests
            .CountAsync(r => r.UserId == userId);

        var pendingRequests = await _context.BloodRequests
            .CountAsync(r => r.UserId == userId && r.Status == "Pending");

        var completedRequests = await _context.BloodRequests
            .CountAsync(r => r.UserId == userId && r.Status == "Completed");

        var donor = await _context.Donors
            .AsNoTracking()
            .SingleOrDefaultAsync(d => d.UserId == userId);

        var recentRequests = await (
            from request in _context.BloodRequests.AsNoTracking()
            join bloodGroup in _context.BloodGroups.AsNoTracking()
                on request.BloodGroupId equals bloodGroup.BloodGroupId
            where request.UserId == userId
            orderby request.CreatedAt descending
            select new DashboardBloodRequest
            {
                BloodRequestId = request.BloodRequestId,
                PatientName = request.PatientName,
                BloodGroup = bloodGroup.BloodGroupName,
                Hospital = request.Hospital,
                RequiredDate = request.RequiredDate,
                EmergencyLevel = request.EmergencyLevel,
                Status = request.Status,
                CreatedAt = request.CreatedAt
            })
            .Take(5)
            .ToListAsync();

        var model = new DashboardViewModel
        {
            UserId = user.UserId,
            FullName = user.FullName,
            Email = user.Email,
            PhoneNumber = user.PhoneNumber,
            IsActive = user.IsActive,
            CreatedAt = user.CreatedAt,
            TotalBloodRequests = totalRequests,
            PendingBloodRequests = pendingRequests,
            CompletedBloodRequests = completedRequests,
            IsDonor = donor != null,
            IsDonorAvailable = donor?.IsAvailable ?? false,
            RecentRequests = recentRequests
        };

        return View(model);
    }
}

