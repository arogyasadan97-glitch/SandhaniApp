using Microsoft.EntityFrameworkCore;
using SandhaniApp.Models;

namespace SandhaniApp.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users => Set<User>();
    public DbSet<UserProfile> UserProfiles => Set<UserProfile>();
    public DbSet<BloodGroup> BloodGroups => Set<BloodGroup>();
    public DbSet<Donor> Donors => Set<Donor>();
    public DbSet<BloodRequest> BloodRequests => Set<BloodRequest>();
    public DbSet<Location> Locations => Set<Location>();
    public DbSet<Admin> Admins => Set<Admin>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("Users");
            entity.HasKey(x => x.UserId);

            entity.Property(x => x.FullName)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(x => x.Email)
                .IsRequired()
                .HasMaxLength(150);

            entity.HasIndex(x => x.Email)
                .IsUnique();

            entity.Property(x => x.PasswordHash)
                .IsRequired()
                .HasMaxLength(500);

            entity.Property(x => x.PhoneNumber)
                .HasMaxLength(20);

            entity.Property(x => x.CreatedAt)
                .HasDefaultValueSql("GETUTCDATE()");

            entity.Property(x => x.IsActive)
                .HasDefaultValue(true);
        });

        modelBuilder.Entity<BloodGroup>(entity =>
        {
            entity.ToTable("BloodGroups");
            entity.HasKey(x => x.BloodGroupId);
            entity.Property(x => x.BloodGroupName)
                .IsRequired()
                .HasMaxLength(10);

            entity.HasIndex(x => x.BloodGroupName)
                .IsUnique();

            entity.HasData(
                new BloodGroup { BloodGroupId = 1, BloodGroupName = "A+" },
                new BloodGroup { BloodGroupId = 2, BloodGroupName = "A-" },
                new BloodGroup { BloodGroupId = 3, BloodGroupName = "B+" },
                new BloodGroup { BloodGroupId = 4, BloodGroupName = "B-" },
                new BloodGroup { BloodGroupId = 5, BloodGroupName = "AB+" },
                new BloodGroup { BloodGroupId = 6, BloodGroupName = "AB-" },
                new BloodGroup { BloodGroupId = 7, BloodGroupName = "O+" },
                new BloodGroup { BloodGroupId = 8, BloodGroupName = "O-" });
        });

        modelBuilder.Entity<Location>(entity =>
        {
            entity.ToTable("Locations");
            entity.HasKey(x => x.LocationId);
            entity.Property(x => x.Division).HasMaxLength(100);
            entity.Property(x => x.District).HasMaxLength(100);
            entity.Property(x => x.Upazila).HasMaxLength(100);
            entity.Property(x => x.Area).HasMaxLength(100);
        });

        modelBuilder.Entity<UserProfile>(entity =>
        {
            entity.ToTable("UserProfiles");
            entity.HasKey(x => x.ProfileId);

            entity.HasIndex(x => x.UserId)
                .IsUnique();

            entity.HasOne(x => x.User)
                .WithOne()
                .HasForeignKey<UserProfile>(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(x => x.BloodGroup)
                .WithMany()
                .HasForeignKey(x => x.BloodGroupId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Donor>(entity =>
        {
            entity.ToTable("Donors");
            entity.HasKey(x => x.DonorId);

            entity.HasIndex(x => x.UserId)
                .IsUnique();

            entity.HasOne(x => x.User)
                .WithMany()
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(x => x.BloodGroup)
                .WithMany()
                .HasForeignKey(x => x.BloodGroupId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.Location)
                .WithMany()
                .HasForeignKey(x => x.LocationId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<BloodRequest>(entity =>
        {
            entity.ToTable("BloodRequests");
            entity.HasKey(x => x.BloodRequestId);

            entity.Property(x => x.PatientName)
                .IsRequired()
                .HasMaxLength(150);

            entity.Property(x => x.ContactNumber)
                .IsRequired()
                .HasMaxLength(20);

            entity.Property(x => x.Hospital)
                .IsRequired()
                .HasMaxLength(200);

            entity.Property(x => x.EmergencyLevel)
                .IsRequired()
                .HasMaxLength(20);

            entity.Property(x => x.Status)
                .IsRequired()
                .HasMaxLength(30)
                .HasDefaultValue("Pending");

            entity.Property(x => x.CreatedAt)
                .HasDefaultValueSql("GETUTCDATE()");

            entity.HasOne(x => x.User)
                .WithMany()
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.SetNull);

            entity.HasOne(x => x.BloodGroup)
                .WithMany()
                .HasForeignKey(x => x.BloodGroupId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.Location)
                .WithMany()
                .HasForeignKey(x => x.LocationId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Admin>(entity =>
        {
            entity.ToTable("Admins");
            entity.HasKey(x => x.AdminId);

            entity.HasIndex(x => x.UserId)
                .IsUnique();

            entity.HasOne(x => x.User)
                .WithMany()
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }
}
