﻿using System;
using System.Collections.Generic;

namespace SandhaniApp.Models
{
    public class DashboardViewModel
    {
        // User information
        public int UserId { get; set; }

        public string FullName { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string? PhoneNumber { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedAt { get; set; }


        // Dashboard statistics
        public int TotalBloodRequests { get; set; }

        public int PendingBloodRequests { get; set; }

        public int CompletedBloodRequests { get; set; }

        public bool IsDonor { get; set; }

        public bool IsDonorAvailable { get; set; }


        // Recent blood requests
        public List<DashboardBloodRequest> RecentRequests { get; set; }
            = new List<DashboardBloodRequest>();
    }


    public class DashboardBloodRequest
    {
        public int BloodRequestId { get; set; }

        public string PatientName { get; set; } = string.Empty;

        public string BloodGroup { get; set; } = string.Empty;

        public string Hospital { get; set; } = string.Empty;

        public DateTime RequiredDate { get; set; }

        public string EmergencyLevel { get; set; } = string.Empty;

        public string Status { get; set; } = string.Empty;

        public DateTime CreatedAt { get; set; }
    }
}