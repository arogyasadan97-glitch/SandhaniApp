﻿using System.ComponentModel.DataAnnotations;

namespace SandhaniApp.Models
{
    public class DonorSearchViewModel
    {
        [Display(Name = "Blood Group")]
        public int? BloodGroupId { get; set; }

        [Display(Name = "Division")]
        public string? Division { get; set; }

        [Display(Name = "District")]
        public string? District { get; set; }

        [Display(Name = "Upazila / Area")]
        public string? Area { get; set; }

        [Display(Name = "Available Donors Only")]
        public bool IsAvailable { get; set; } = true;

        public List<BloodGroup> BloodGroups { get; set; }
            = new List<BloodGroup>();

        public List<DonorSearchResult> Results { get; set; }
            = new List<DonorSearchResult>();
    }

    public class DonorSearchResult
    {
        public int DonorId { get; set; }

        public int UserId { get; set; }

        public string FullName { get; set; } = string.Empty;

        public string? PhoneNumber { get; set; }

        public string BloodGroup { get; set; } = string.Empty;

        public string? Division { get; set; }

        public string? District { get; set; }

        public string? Area { get; set; }

        public DateTime? LastDonationDate { get; set; }

        public bool IsAvailable { get; set; }
    }
}