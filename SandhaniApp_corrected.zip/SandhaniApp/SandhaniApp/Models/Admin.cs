﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SandhaniApp.Models
{
    [Table("Admins")]
    public class Admin
    {
        [Key]
        public int AdminId { get; set; }

        public int UserId { get; set; }

        public DateTime CreatedAt { get; set; }

        // Navigation property
        public User? User { get; set; }
    }
}