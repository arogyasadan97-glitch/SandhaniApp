﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SandhaniApp.Models
{
    [Table("BloodRequests")]
    public class BloodRequest
    {
        [Key]
        public int BloodRequestId { get; set; }

        public int? UserId { get; set; }

        public int BloodGroupId { get; set; }

        public int? LocationId { get; set; }

        [Required]
        [StringLength(150)]
        public string PatientName { get; set; } = string.Empty;

        [Required]
        [StringLength(20)]
        public string ContactNumber { get; set; } = string.Empty;

        public int RequiredQuantity { get; set; }

        [Required]
        [StringLength(200)]
        public string Hospital { get; set; } = string.Empty;

        public DateTime RequiredDate { get; set; }

        [Required]
        [StringLength(20)]
        public string EmergencyLevel { get; set; } = "Normal";

        [StringLength(1000)]
        public string? Description { get; set; }

        [Required]
        [StringLength(30)]
        public string Status { get; set; } = "Pending";

        public DateTime CreatedAt { get; set; }

        public User? User { get; set; }

        public BloodGroup? BloodGroup { get; set; }

        public Location? Location { get; set; }
    }
}