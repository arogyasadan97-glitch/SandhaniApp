using System.ComponentModel.DataAnnotations;

namespace SandhaniApp.Models
{
    public class RequestBloodViewModel
    {
        [Required(ErrorMessage = "Patient name is required.")]
        [Display(Name = "Patient Name")]
        public string PatientName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Contact number is required.")]
        [Display(Name = "Contact Number")]
        public string ContactNumber { get; set; } = string.Empty;

        [Range(1, int.MaxValue, ErrorMessage = "Please select a blood group.")]
        [Display(Name = "Blood Group")]
        public int BloodGroupId { get; set; }

        [Required(ErrorMessage = "Please enter the required quantity.")]
        [Range(1, 20, ErrorMessage = "Quantity must be between 1 and 20 bags.")]
        [Display(Name = "Required Quantity")]
        public int RequiredQuantity { get; set; }

        [Required(ErrorMessage = "Hospital name is required.")]
        public string Hospital { get; set; } = string.Empty;

        [Required(ErrorMessage = "Required date is required.")]
        [DataType(DataType.Date)]
        [Display(Name = "Required Date")]
        public DateTime RequiredDate { get; set; }

        [Required(ErrorMessage = "Please select emergency level.")]
        [Display(Name = "Emergency Level")]
        public string EmergencyLevel { get; set; } = "Normal";

        [Display(Name = "Division")]
        public string? Division { get; set; }

        [Display(Name = "District")]
        public string? District { get; set; }

        [Display(Name = "Area / Upazila")]
        public string? Area { get; set; }

        [Display(Name = "Additional Information")]
        public string? Description { get; set; }
    }
}