﻿using System.Collections.Generic;

namespace SandhaniApp.Models
{
    public class SearchModel
    {
        public string BloodGroup { get; set; }

        public List<string> BloodGroups { get; set; }

        public string Division { get; set; }

        public string District { get; set; }

        public string Area { get; set; }

        public SearchModel()
        {
            BloodGroups = new List<string>
            {
                "A+",
                "A-",
                "B+",
                "B-",
                "AB+",
                "AB-",
                "O+",
                "O-"
            };
        }
    }
}