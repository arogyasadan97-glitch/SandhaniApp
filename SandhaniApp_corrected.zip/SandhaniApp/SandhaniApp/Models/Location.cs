using System.ComponentModel.DataAnnotations;

namespace SandhaniApp.Models;

public class Location
{
    public int LocationId { get; set; }

    [StringLength(100)]
    public string? Division { get; set; }

    [StringLength(100)]
    public string? Upazila { get; set; }

    [StringLength(100)]
    public string? District { get; set; }

    [StringLength(100)]
    public string? Area { get; set; }
}
