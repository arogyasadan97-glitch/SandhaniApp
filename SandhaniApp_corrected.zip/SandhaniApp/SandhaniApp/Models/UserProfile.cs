﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SandhaniApp.Models
{
    [Table("UserProfiles")]
    public class UserProfile
    {
        [Key]
        public int ProfileId { get; set; }

        public int UserId { get; set; }

        public DateTime? DateOfBirth { get; set; }

        [StringLength(20)]
        public string? Gender { get; set; }

        public int? BloodGroupId { get; set; }

        [StringLength(250)]
        public string? Address { get; set; }

        [StringLength(100)]
        public string? City { get; set; }

        [StringLength(100)]
        public string? District { get; set; }

        [StringLength(500)]
        public string? ProfileImage { get; set; }

        public DateTime CreatedAt { get; set; }

        // Navigation properties
        public User? User { get; set; }

        public BloodGroup? BloodGroup { get; set; }
    }
}