//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;

//namespace SandhaniApp.Models
//{
//    public class User
//    {
//        public int Id { get; set; }

//        [Required, StringLength(100)]
//        public string FullName { get; set; } = string.Empty;

//        [Required, EmailAddress, StringLength(150)]
//        public string Email { get; set; } = string.Empty;

//        // Never store a plain-text password.
//        public string PasswordHash { get; set; } = string.Empty;

//        public DateTime CreatedAt { get; set; }
//    }
//}



using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SandhaniApp.Models
{
    [Table("Users")]
    public class User
    {
        [Key]
        [Column("UserId")]
        public int UserId { get; set; }

        [Required]
        [StringLength(100)]
        public string FullName { get; set; } = string.Empty;

        [Required]
        [StringLength(150)]
        public string Email { get; set; } = string.Empty;

        [Required]
        [StringLength(500)]
        public string PasswordHash { get; set; } = string.Empty;

        [StringLength(20)]
        public string? PhoneNumber { get; set; }

        public DateTime CreatedAt { get; set; }

        public bool IsActive { get; set; }
    }
}