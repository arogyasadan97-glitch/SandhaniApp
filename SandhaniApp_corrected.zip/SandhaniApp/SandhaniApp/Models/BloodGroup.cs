using System.ComponentModel.DataAnnotations;

namespace SandhaniApp.Models;

public class BloodGroup
{
    public int BloodGroupId { get; set; }

    [Required]
    [StringLength(10)]
    public string BloodGroupName { get; set; } = string.Empty;
}
