﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SandhaniApp.Models
{
    [Table("Donors")]
    public class Donor
    {
        [Key]
        public int DonorId { get; set; }

        public int UserId { get; set; }

        public int BloodGroupId { get; set; }

        public int? LocationId { get; set; }

        public DateTime? LastDonationDate { get; set; }

        public bool IsAvailable { get; set; }

        public DateTime CreatedAt { get; set; }

        // Navigation properties
        public User? User { get; set; }

        public BloodGroup? BloodGroup { get; set; }

        public Location? Location { get; set; }
    }
}