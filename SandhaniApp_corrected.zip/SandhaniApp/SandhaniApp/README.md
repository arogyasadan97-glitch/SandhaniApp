# SandhaniApp

ASP.NET Core MVC application targeting .NET 8.

## Important setup

This cleaned version removes the old .NET MAUI `AppShell.xaml` and Razor Pages leftovers. It uses ASP.NET Core MVC, EF Core SQL Server, and cookie authentication.

### 1. Check SQL Server

Update `appsettings.json` if your SQL Server instance, database name, or credentials are different from the current `DefaultConnection`.

### 2. Create a fresh development database

The original project contained a migration for a different schema. Do not reuse that migration.

If the old `SandhaniDB` database is only test data, remove it first. Then open Visual Studio Package Manager Console in the `SandhaniApp` project and run:

```powershell
Add-Migration InitialCreate
Update-Database
```

Alternatively, with the EF CLI:

```bash
dotnet restore
dotnet ef migrations add InitialCreate
dotnet ef database update
```

The application also calls `Database.Migrate()` at startup, so subsequent migrations are applied automatically.

### 3. Run

Use the `https` or `http` launch profile from Visual Studio, or run:

```bash
dotnet run
```

### 4. Create an admin

Register a normal account first. Then, in SQL Server, add that user's ID to `Admins`:

```sql
INSERT INTO Admins (UserId, CreatedAt)
SELECT UserId, GETUTCDATE()
FROM Users
WHERE Email = 'your-email@example.com';
```

The next time that user logs in, SandhaniApp will add the `Admin` role claim and the Admin Panel will be available.

## Main fixes in this version

- Replaced the broken `Models/Program.cs` with a single root `Program.cs`.
- Removed duplicate EF Core, authentication, authorization, and MVC registrations.
- Removed invalid `AddIdentity<...>()` code.
- Restored `app.Run()` correctly.
- Removed MAUI `AppShell.xaml` from the MVC project.
- Rebuilt `ApplicationDbContext` to match the current models.
- Added the eight blood groups as EF Core seed data.
- Replaced the obsolete migration with a fresh migration workflow.
- Fixed the Dashboard controller's unreachable code and missing `return View(model)`.
- Fixed the Dashboard view's duplicate `@model` declarations.
- Converted the Admin dashboard back to a normal MVC view.
- Removed unused Razor Page `.cshtml.cs` files from MVC views.
- Added the missing Home/About action and view.
- Fixed the Home page Find Donor link.
- Removed stray Markdown code fences from the Donor Search view.
- Normalized registration/login email addresses.
- Added Admin role claims based on the `Admins` table.
- Saved the authenticated user's ID with blood requests.
